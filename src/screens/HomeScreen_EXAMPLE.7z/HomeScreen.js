/**
 * Home Dashboard Screen
 * Complete dashboard with real-time data from database
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  RefreshControl,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Colors from '../styles/colors';
import {
  getAllProducts,
  getLowStockProducts,
  getNearExpiryProducts,
} from '../database/queries/products';
import {
  getRecentTransactions,
  getTransactionStats,
} from '../database/queries/transactions';
import { countExpiringProducts } from '../database/batchTracking';

export default function HomeScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    totalProducts: 0,
    lowStockCount: 0,
    nearExpiryCount: 0,
    totalValue: 0,
    totalStockIn: 0,
    totalStockOut: 0,
  });
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [lowStockProducts, setLowStockProducts] = useState([]);

  // Load data when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      loadDashboardData();
    }, [])
  );

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Get all products
      const allProducts = await getAllProducts();

      // Get low stock products
      const lowStock = await getLowStockProducts();

      // Get near expiry products (within 30 days)
      const expiring = await getNearExpiryProducts(30);

      // Get expiring batches count (more accurate for batch tracking)
      const expiringBatchesCount = await countExpiringProducts(30);

      // Calculate total inventory value
      const totalValue = allProducts.reduce((sum, product) => {
        return sum + product.selling_price * product.current_stock;
      }, 0);

      // Get transaction statistics
      const transactionStats = await getTransactionStats();

      // Get recent transactions
      const recent = await getRecentTransactions(5);

      // Update state
      setStats({
        totalProducts: allProducts.length,
        lowStockCount: lowStock.length,
        nearExpiryCount: Math.max(expiring.length, expiringBatchesCount), // Use higher count
        totalValue: totalValue,
        totalStockIn: transactionStats.totalIn,
        totalStockOut: transactionStats.totalOut,
      });

      setRecentTransactions(recent);
      setLowStockProducts(lowStock.slice(0, 3)); // Top 3 low stock items
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      Alert.alert('Error', 'Gagal memuat data dashboard');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadDashboardData();
  };

  const formatCurrency = (value) => {
    return `Rp ${Math.round(value).toLocaleString('id-ID')}`;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Hari ini';
    if (diffDays === 1) return 'Kemarin';
    if (diffDays < 7) return `${diffDays} hari lalu`;

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    return `${day}/${month}`;
  };

  const getTodayDate = () => {
    const days = [
      'Minggu',
      'Senin',
      'Selasa',
      'Rabu',
      'Kamis',
      'Jumat',
      'Sabtu',
    ];
    const months = [
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];

    const now = new Date();
    const dayName = days[now.getDay()];
    const day = now.getDate();
    const month = months[now.getMonth()];
    const year = now.getFullYear();

    return `${dayName}, ${day} ${month} ${year}`;
  };

  const handleNavigateToInventory = () => {
    navigation.navigate('Inventory');
  };

  const handleNavigateToLowStock = () => {
    navigation.navigate('Inventory');
    // TODO: Implement filter trigger for low stock
  };

  const handleNavigateToExpiring = () => {
    navigation.navigate('Inventory', {
      screen: 'ExpiringBatches',
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.cardBlue} />
          <Text style={styles.loadingText}>Memuat Dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Selamat Datang 👋</Text>
          <Text style={styles.dateText}>{getTodayDate()}</Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={styles.bell}
            onPress={() => navigation.navigate('Notifications')}
          >
            <Text style={styles.bellIcon}>🔔</Text>
            {(stats.lowStockCount > 0 || stats.nearExpiryCount > 0) && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>
                  {stats.lowStockCount + stats.nearExpiryCount}
                </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Main Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Ringkasan</Text>
          <View style={styles.statsGrid}>
            <TouchableOpacity
              style={[styles.statCard, styles.statCardBlue]}
              onPress={handleNavigateToInventory}
              activeOpacity={0.7}
            >
              <View style={styles.statIcon}>
                <Text style={styles.statIconText}>📦</Text>
              </View>
              <Text style={styles.statValue}>{stats.totalProducts}</Text>
              <Text style={styles.statLabel}>Total Produk</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.statCard, styles.statCardGreen]}
              onPress={handleNavigateToInventory}
              activeOpacity={0.7}
            >
              <View style={styles.statIcon}>
                <Text style={styles.statIconText}>💰</Text>
              </View>
              <Text style={styles.statValue}>
                {stats.totalValue > 1000000
                  ? `${(stats.totalValue / 1000000).toFixed(1)}jt`
                  : stats.totalValue > 1000
                  ? `${(stats.totalValue / 1000).toFixed(0)}rb`
                  : stats.totalValue}
              </Text>
              <Text style={styles.statLabel}>Nilai Stok</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.statsGrid}>
            <TouchableOpacity
              style={[styles.statCard, styles.statCardRed]}
              onPress={handleNavigateToLowStock}
              activeOpacity={0.7}
            >
              <View style={styles.statIcon}>
                <Text style={styles.statIconText}>⚠️</Text>
              </View>
              <Text style={styles.statValue}>{stats.lowStockCount}</Text>
              <Text style={styles.statLabel}>Stok Rendah</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.statCard, styles.statCardOrange]}
              onPress={handleNavigateToExpiring}
              activeOpacity={0.7}
            >
              <View style={styles.statIcon}>
                <Text style={styles.statIconText}>⏰</Text>
              </View>
              <Text style={styles.statValue}>{stats.nearExpiryCount}</Text>
              <Text style={styles.statLabel}>Akan Kadaluarsa</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Transaction Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📈 Transaksi</Text>
          <View style={styles.transactionStats}>
            <View style={styles.transactionStatItem}>
              <View style={[styles.transactionDot, { backgroundColor: '#10B981' }]} />
              <View style={styles.transactionStatContent}>
                <Text style={styles.transactionStatValue}>
                  {stats.totalStockIn}
                </Text>
                <Text style={styles.transactionStatLabel}>Stok Masuk</Text>
              </View>
            </View>
            <View style={styles.transactionDivider} />
            <View style={styles.transactionStatItem}>
              <View style={[styles.transactionDot, { backgroundColor: '#EF4444' }]} />
              <View style={styles.transactionStatContent}>
                <Text style={styles.transactionStatValue}>
                  {stats.totalStockOut}
                </Text>
                <Text style={styles.transactionStatLabel}>Stok Keluar</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Low Stock Alert */}
        {lowStockProducts.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>⚠️ Perlu Perhatian</Text>
              <TouchableOpacity onPress={handleNavigateToLowStock}>
                <Text style={styles.seeAllText}>Lihat Semua →</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.alertCard}>
              {lowStockProducts.map((product, index) => (
                <View key={product.id}>
                  <TouchableOpacity
                    style={styles.alertItem}
                    onPress={() =>
                      navigation.navigate('Inventory', {
                        screen: 'ItemDetail',
                        params: { productId: product.id },
                      })
                    }
                  >
                    <View style={styles.alertIcon}>
                      <Text style={styles.alertIconText}>📦</Text>
                    </View>
                    <View style={styles.alertContent}>
                      <Text style={styles.alertProductName} numberOfLines={1}>
                        {product.name}
                      </Text>
                      <Text style={styles.alertProductDetail}>
                        Stok: {product.current_stock} {product.unit} (Min:{' '}
                        {product.min_stock_threshold})
                      </Text>
                    </View>
                    <View style={styles.alertBadge}>
                      <Text style={styles.alertBadgeText}>Rendah</Text>
                    </View>
                  </TouchableOpacity>
                  {index < lowStockProducts.length - 1 && (
                    <View style={styles.alertDivider} />
                  )}
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Recent Transactions */}
        {recentTransactions.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>🕒 Aktivitas Terakhir</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Management')}>
                <Text style={styles.seeAllText}>Lihat Semua →</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.transactionCard}>
              {recentTransactions.map((transaction, index) => (
                <View key={transaction.id}>
                  <View style={styles.transactionItem}>
                    <View
                      style={[
                        styles.transactionIcon,
                        {
                          backgroundColor:
                            transaction.type === 'IN' ? '#D1FAE5' : '#FEE2E2',
                        },
                      ]}
                    >
                      <Text style={styles.transactionIconText}>
                        {transaction.type === 'IN' ? '📥' : '📤'}
                      </Text>
                    </View>
                    <View style={styles.transactionContent}>
                      <Text style={styles.transactionProductName} numberOfLines={1}>
                        {transaction.product_name}
                      </Text>
                      <Text style={styles.transactionDetail}>
                        {transaction.type === 'IN' ? '+' : '-'}
                        {transaction.quantity} {transaction.unit}
                      </Text>
                    </View>
                    <View style={styles.transactionRight}>
                      <Text style={styles.transactionDate}>
                        {formatDate(transaction.transaction_date)}
                      </Text>
                      <View
                        style={[
                          styles.transactionBadge,
                          {
                            backgroundColor:
                              transaction.type === 'IN' ? '#10B981' : '#EF4444',
                          },
                        ]}
                      >
                        <Text style={styles.transactionBadgeText}>
                          {transaction.type === 'IN' ? 'Masuk' : 'Keluar'}
                        </Text>
                      </View>
                    </View>
                  </View>
                  {index < recentTransactions.length - 1 && (
                    <View style={styles.transactionDivider} />
                  )}
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>⚡ Aksi Cepat</Text>
          <View style={styles.quickActions}>
            <TouchableOpacity
              style={styles.quickActionButton}
              onPress={() =>
                navigation.navigate('Inventory', {
                  screen: 'AddItem',
                })
              }
            >
              <View style={styles.quickActionIcon}>
                <Text style={styles.quickActionIconText}>➕</Text>
              </View>
              <Text style={styles.quickActionText}>Tambah Produk</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionButton}
              onPress={() => navigation.navigate('Inventory')}
            >
              <View style={styles.quickActionIcon}>
                <Text style={styles.quickActionIconText}>📦</Text>
              </View>
              <Text style={styles.quickActionText}>Lihat Stok</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionButton}
              onPress={handleNavigateToLowStock}
            >
              <View style={styles.quickActionIcon}>
                <Text style={styles.quickActionIconText}>⚠️</Text>
              </View>
              <Text style={styles.quickActionText}>Stok Rendah</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionButton}
              onPress={handleNavigateToExpiring}
            >
              <View style={styles.quickActionIcon}>
                <Text style={styles.quickActionIconText}>⏰</Text>
              </View>
              <Text style={styles.quickActionText}>Kadaluarsa</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Empty State */}
        {stats.totalProducts === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>📦</Text>
            <Text style={styles.emptyTitle}>Belum Ada Produk</Text>
            <Text style={styles.emptyText}>
              Mulai tambahkan produk untuk mengelola stok Anda
            </Text>
            <TouchableOpacity
              style={styles.emptyButton}
              onPress={() =>
                navigation.navigate('Inventory', {
                  screen: 'AddItem',
                })
              }
            >
              <Text style={styles.emptyButtonText}>+ Tambah Produk Pertama</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: Colors.textLight,
  },

  // Header
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.textDark,
  },
  dateText: {
    fontSize: 14,
    color: Colors.textLight,
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bell: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  bellIcon: {
    fontSize: 20,
  },
  badge: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: '#EF4444',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
  },
  badgeText: {
    color: Colors.white,
    fontSize: 11,
    fontWeight: '700',
  },

  // Content
  content: {
    paddingVertical: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 24,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  seeAllText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.cardBlue,
  },

  // Stats Grid
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 16,
    minHeight: 120,
  },
  statCardBlue: {
    backgroundColor: Colors.cardBlue,
  },
  statCardGreen: {
    backgroundColor: '#10B981',
  },
  statCardRed: {
    backgroundColor: '#EF4444',
  },
  statCardOrange: {
    backgroundColor: '#F59E0B',
  },
  statIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  statIconText: {
    fontSize: 18,
  },
  statValue: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 13,
    color: Colors.white,
    opacity: 0.9,
  },

  // Transaction Stats
  transactionStats: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.divider,
  },
  transactionStatItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  transactionDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  transactionStatContent: {
    flex: 1,
  },
  transactionStatValue: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.textDark,
  },
  transactionStatLabel: {
    fontSize: 13,
    color: Colors.textLight,
    marginTop: 2,
  },
  transactionDivider: {
    width: 1,
    backgroundColor: Colors.divider,
    marginHorizontal: 16,
  },

  // Alert Card
  alertCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FEE2E2',
    overflow: 'hidden',
  },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  alertIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FEE2E2',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  alertIconText: {
    fontSize: 18,
  },
  alertContent: {
    flex: 1,
  },
  alertProductName: {
    fontSize: 15,
    fontWeight: '600',
    color: Colors.textDark,
  },
  alertProductDetail: {
    fontSize: 13,
    color: Colors.textLight,
    marginTop: 2,
  },
  alertBadge: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  alertBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: Colors.white,
  },
  alertDivider: {
    height: 1,
    backgroundColor: Colors.divider,
    marginLeft: 68,
  },

  // Transaction Card
  transactionCard: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.divider,
    overflow: 'hidden',
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  transactionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  transactionIconText: {
    fontSize: 18,
  },
  transactionContent: {
    flex: 1,
  },
  transactionProductName: {
    fontSize: 15,
    fontWeight: '600',
    color: Colors.textDark,
  },
  transactionDetail: {
    fontSize: 13,
    color: Colors.textLight,
    marginTop: 2,
  },
  transactionRight: {
    alignItems: 'flex-end',
  },
  transactionDate: {
    fontSize: 12,
    color: Colors.textLight,
    marginBottom: 4,
  },
  transactionBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  transactionBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: Colors.white,
  },

  // Quick Actions
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickActionButton: {
    width: '48%',
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.divider,
    alignItems: 'center',
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  quickActionIconText: {
    fontSize: 24,
  },
  quickActionText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textDark,
    textAlign: 'center',
  },

  // Empty State
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 40,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.textDark,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 15,
    color: Colors.textLight,
    textAlign: 'center',
    marginBottom: 24,
  },
  emptyButton: {
    backgroundColor: Colors.cardBlue,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 12,
  },
  emptyButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: Colors.white,
  },
});
